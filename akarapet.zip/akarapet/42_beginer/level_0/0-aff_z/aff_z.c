// Passed Moulinette 2019.09.01

#include <unistd.h>

int		main(void)
{
	write(1, "z\n", 2);
	return (0);
}